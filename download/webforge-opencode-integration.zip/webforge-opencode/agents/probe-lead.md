---
description: "Probe Team Lead in the Intelligence department — intelligence department"
mode: subagent
color: "#3b82f6"
steps: 5
hidden: true
permission:
    read: allow
    edit: deny
    bash: deny
    task: deny
    websearch: allow
    webfetch: allow
    glob: allow
    grep: allow
    list: allow
    todowrite: deny
    question: allow
    skill: allow
---

